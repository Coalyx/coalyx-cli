
# AIMO 3: ADAPTIVE UNCERTAINTY-AWARE PIPELINE
*(Kiến trúc AI Tự nhận thức độ Bất định)*
Báo cáo này giải thích cách tiếp cận đưa **Nhận thức Bất định (Uncertainty Awareness)** vào hệ thống thi đấu, thoát khỏi lối mòn "Cào bằng tài nguyên" (Brute-force Ensemble) thông thường.
## 1. DATA FLOW (Luồng dữ liệu Tự thích nghi)
```mermaid
graph TD
    A[AIMO 3 API] --> B[solve_problem]
    
    subgraph Stage 1: Fast Probe
        B -->|N=4, Temp=0.6| C[generate_candidates]
        C --> D[measure_uncertainty]
    end
    
    D --> E{Uncertainty Gate\n(Độ phân tán đáp án)}
    
    %% Nhánh Tự tin
    E -->|Certainty >= 75%\n(Đồng thuận cao)| F[Final Answer]
    
    %% Nhánh Bất định (Hoang mang)
    E -->|Certainty < 75%\n(Mô hình đưa ra nhiều đáp án khác nhau)| G[Stage 2: Self-Doubt Activation]
    
    subgraph Stage 2: Reflection & Cautious Search
        G -->|Bơm danh sách đáp án mâu thuẫn vào Prompt| H[generate_candidates\nN=6, Temp=0.9]
        H --> I[Gộp kết quả S1 + S2]
        I --> J[Majority Vote chung cuộc]
    end
    
    J --> F
    F --> K[AIMO 3 API:\nenv.predict]

```
## 2. TRIẾT LÝ THIẾT KẾ VÀ CÔNG NĂNG (INSIGHTS)
### 2.1. Đo lường "Epistemic Uncertainty" trong vLLM
Trong các framework tối ưu tốc độ như vLLM, việc trích xuất Logit Entropy ở giữa quá trình sinh từ là bất khả thi. Do đó, mã nguồn sử dụng **Độ phân tán đầu ra (Output Variance)** của Stage 1 làm thước đo cho Epistemic Uncertainty (Sự bất định do thiếu kiến thức/bẫy logic).
 * *Insight:* Nếu 4 path đầu tiên cho ra [42, 42, 42, 42], mô hình hoàn toàn làm chủ được bài toán. Nếu nó cho ra [42, 15, 100, 7], mô hình đang rơi vào trạng thái ảo giác hoặc đạp trúng bẫy (Uncertainty cực cao).
### 2.2. Uncertainty Gate & Dynamic Scaling (Tối ưu Tài nguyên)
 * Thay vì mù quáng chạy N=10 cho mọi bài toán (làm lãng phí thời gian GPU cho các bài dễ), hệ thống chia làm 2 giai đoạn.
 * Nếu bài dễ (Uncertainty thấp), nó tiêu thụ chỉ 4 paths rồi đi tiếp.
 * Khoảng thời gian tiết kiệm được sẽ được dồn cho các bài cực khó (kích hoạt Stage 2, tổng cộng 10 paths).
### 2.3. Prompt "Self-Doubt" Dựa trên Bằng chứng
 * Nếu phát hiện Uncertainty, thay vì chỉ dặn mô hình "Hãy cẩn thận" một cách chung chung, **chúng ta bơm chính những sai lầm của nó vào Prompt**: *"We attempted to solve this... but received conflicting answers: {unique_ans}"*.
 * *Insight (Từ Aletheia):* Đây là kỹ thuật *Contrastive Grounding*. Khi mô hình nhìn thấy chính nó đã từng ra các đáp án mâu thuẫn, nó sẽ thoát khỏi quán tính "Tự hợp lý hóa" (Self-rationalization). Nó buộc phải chạy một thuật toán phản biện bên trong để tìm ra điểm hổng khiến kết quả bị phân nhánh, từ đó tạo ra các path có chất lượng cao hơn ở Stage 2.