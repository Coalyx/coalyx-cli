# %% [markdown]
# # AIMO 3: Adaptive Uncertainty-Aware Reasoning Pipeline (Transformers Edition)
# 
# This notebook implements a two-stage mathematical reasoning pipeline optimized for the Kaggle AIMO 3 competition. 
# Utilizing Hugging Face `transformers` and `accelerate`, the system dynamically measures epistemic uncertainty through output variance.
# 
# - **Stage 1 (Fast Probe):** Generates initial candidate solutions to measure consensus.
# - **Stage 2 (Self-Doubt Activation):** Triggered only when uncertainty is high. It injects prior conflicting answers into the prompt, forcing the model to re-evaluate edge cases and correct logical flaws.

# %%
import os
import re
import gc
import torch
import pandas as pd
import polars as pl
from collections import Counter
from typing import Optional, Tuple, List
from transformers import AutoModelForCausalLM, AutoTokenizer
import kaggle_evaluation.aimo_3_inference_server

# %% [markdown]
# ## 1. Configurations & Prompts
# Define global constants, model paths, and the exact prompts used for standard generation and self-reflection.

# %%
MODEL_PATH = "/kaggle/input/gpt-oss-120b"
MAX_TOKENS = 2048
BATCH_SIZE = 2  # Micro-batching size to prevent VRAM OOM during HF generation

STANDARD_PROMPT = (
    "You are an elite mathematical reasoning AI. "
    "Solve the problem step-by-step. "
    "You must end your solution by placing the final numerical answer inside \\boxed{}. "
    "The final answer must be a non-negative integer."
)

SELF_DOUBT_PROMPT = (
    "You are an expert mathematical auditor. "
    "We attempted to solve this problem but received conflicting answers: {conflicting_answers}. "
    "This indicates a high probability of logical traps or calculation errors. "
    "Please rethink the problem from first principles, identify the potential trap, "
    "and provide the definitive step-by-step solution. "
    "End your solution with the final numerical answer inside \\boxed{}."
)

# %% [markdown]
# ## 2. Core LLM & Generation Modules
# Pure functions to initialize the model and handle batched text generation via Hugging Face.

# %%
def init_model(model_path: str) -> Tuple[AutoModelForCausalLM, AutoTokenizer]:
    """
    Initialize the Hugging Face model and tokenizer utilizing accelerate for multi-GPU.
    """
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        device_map="auto",
        torch_dtype="auto",
        trust_remote_code=True
    )
    model.eval()
    
    return model, tokenizer

def generate_candidates(
    model: AutoModelForCausalLM, 
    tokenizer: AutoTokenizer, 
    prompt: str, 
    num_samples: int, 
    temperature: float
) -> List[str]:
    """
    Generate multiple candidate solutions using safe micro-batching to prevent OOM.
    """
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    prompt_length = inputs.input_ids.shape[1]
    
    generated_texts = []
    
    with torch.no_grad():
        for _ in range(0, num_samples, BATCH_SIZE):
            current_batch = min(BATCH_SIZE, num_samples - len(generated_texts))
            
            outputs = model.generate(
                **inputs,
                max_new_tokens=MAX_TOKENS,
                do_sample=True,
                temperature=temperature,
                top_p=0.95,
                num_return_sequences=current_batch,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id
            )
            
            for output in outputs:
                generated_tokens = output[prompt_length:]
                text = tokenizer.decode(generated_tokens, skip_special_tokens=True)
                
                if "</solve>" in text:
                    text = text.split("</solve>")[0]
                    
                generated_texts.append(text)
                
            # Free up tensor memory after each micro-batch
            del outputs
            torch.cuda.empty_cache()
            
    return generated_texts

# %% [markdown]
# ## 3. Extraction & Uncertainty Measurement
# Functions to robustly parse the output and quantify the model's confidence based on consensus.

# %%
def extract_answer(text: str) -> Optional[int]:
    """
    Extract the numerical answer from the \boxed{} format.
    Falls back to the last numerical value in the text if the format is missing.
    Applies modulo 1000 per AIMO rules.
    """
    match = re.search(r'\\boxed\{([^{}]*)\}', text)
    if match:
        try:
            num = float(match.group(1).strip())
            if num.is_integer():
                return int(num) % 1000
        except ValueError:
            pass
            
    matches = re.findall(r'\d+', text)
    return int(matches[-1]) % 1000 if matches else None

def measure_uncertainty(candidates: List[str]) -> Tuple[int, float, List[int]]:
    """
    Quantify epistemic uncertainty by analyzing the distribution of generated answers.
    Returns the most common answer, its certainty ratio, and a list of all unique answers.
    """
    answers = [extract_answer(text) for text in candidates]
    valid_answers = [a for a in answers if a is not None and a >= 0]
    
    if not valid_answers:
        return 0, 0.0, []
        
    counts = Counter(valid_answers)
    best_answer, max_votes = counts.most_common(1)[0]
    certainty_ratio = max_votes / len(valid_answers)
    unique_answers = list(counts.keys())
    
    return best_answer, certainty_ratio, unique_answers

# %% [markdown]
# ## 4. The Adaptive Pipeline Orchestrator
# Executes the 2-stage logic. Memory cleanup is strictly enforced to prevent OOM errors over the test set.

# %%
def solve_problem(model: AutoModelForCausalLM, tokenizer: AutoTokenizer, problem: str) -> int:
    """
    Orchestrate the 2-stage uncertainty-aware reasoning pipeline.
    """
    prompt_stage_1 = f"{STANDARD_PROMPT}\n\nProblem:\n{problem}\n\nSolution:\n"
    candidates_s1 = generate_candidates(model, tokenizer, prompt_stage_1, num_samples=4, temperature=0.6)
    
    ans_s1, certainty, unique_ans = measure_uncertainty(candidates_s1)
    
    if certainty >= 0.75:
        final_answer = ans_s1
    else:
        prompt_stage_2 = SELF_DOUBT_PROMPT.format(conflicting_answers=unique_ans)
        prompt_stage_2 = f"{prompt_stage_2}\n\nProblem:\n{problem}\n\nSolution:\n"
        
        candidates_s2 = generate_candidates(model, tokenizer, prompt_stage_2, num_samples=6, temperature=0.9)
        
        all_candidates = candidates_s1 + candidates_s2
        final_answer, _, _ = measure_uncertainty(all_candidates)
    
    gc.collect()
    torch.cuda.empty_cache()
    
    return final_answer

# %% [markdown]
# ## 5. Kaggle Submission Execution
# Interface with the new Kaggle AIMO 3 inference server. 
# Implements lazy loading to comply with the competition's fast-fail initialization requirement.

# %%
class AdaptiveModel:
    """
    Lazy-loading wrapper for the LLM. Ensures the model is only loaded 
    on the first prediction call, avoiding initialization timeouts.
    """
    def __init__(self):
        self.model = None
        self.tokenizer = None

    def load(self) -> Tuple[AutoModelForCausalLM, AutoTokenizer]:
        """
        Load the Hugging Face model and tokenizer.
        """
        print("Loading Hugging Face engine via Accelerate...")
        return init_model(MODEL_PATH)

    def predict(self, problem_text: str) -> int:
        """
        Execute the inference pipeline on the problem text.
        """
        if self.model is None or self.tokenizer is None:
            self.model, self.tokenizer = self.load()
        return solve_problem(self.model, self.tokenizer, problem_text)

global_model = AdaptiveModel()

def predict_endpoint(id_: pl.Series, problem: pl.Series) -> pl.DataFrame:
    """
    Prediction endpoint called by the AIMO 3 Inference Server.
    """
    id_val = id_.item(0)
    problem_text = problem.item(0)
    
    prediction = global_model.predict(problem_text)
    
    return pl.DataFrame({'id': id_val, 'answer': prediction})

def main():
    """
    Main execution setup for the Kaggle evaluation server.
    """
    inference_server = kaggle_evaluation.aimo_3_inference_server.AIMO3InferenceServer(
        predict_endpoint
    )
    
    if os.getenv('KAGGLE_IS_COMPETITION_RERUN'):
        inference_server.serve()
    else:
        inference_server.run_local_gateway(
            ('/kaggle/input/ai-mathematical-olympiad-progress-prize-3/test.csv',)
        )

if __name__ == "__main__":
    main()



