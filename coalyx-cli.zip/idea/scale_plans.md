Có, **scale được ra bài toán mở**, nhưng không thể giữ nguyên cơ chế `\boxed{integer}` + majority vote theo nghĩa hẹp. Phần lõi của hệ thống của bạn rất tốt: **sample nhiều reasoning path → đo bất định → kích hoạt self-doubt khi phân kỳ → tổng hợp lại**. Tuy nhiên, khi rời khỏi toán có đáp án số, bạn phải thay “đồng thuận đáp án” bằng **đồng thuận ngữ nghĩa / đồng thuận luận điểm / đồng thuận bằng chứng**.

Nói gọn: kiến trúc này có thể trở thành một **Adaptive Uncertainty-Aware Reasoning Pipeline for Open-Ended Problems**, nhưng cần một tầng trung gian biến text tự do thành biểu diễn có thể so sánh.

---

## 1. Cái gì giữ nguyên được?

Pipeline hiện tại có 4 ý tưởng nền tảng rất mạnh:

```text
Generate multiple candidates
→ Extract answer
→ Measure uncertainty
→ Trigger deeper reasoning if uncertainty is high
```

Với bài toán toán học AIMO:

```text
Candidate text → boxed integer → majority vote
```

Với bài toán mở:

```text
Candidate text → semantic thesis / claims / assumptions / evidence
→ semantic clustering / judge scoring / contradiction detection
→ synthesis final response
```

Tức là không bỏ kiến trúc. Ta chỉ thay bộ phận **extract_answer** và **measure_uncertainty**.

---

# 2. Vấn đề cốt lõi khi chuyển sang bài toán mở

Trong toán AIMO, hai lời giải có thể khác diễn đạt nhưng cuối cùng đều về một con số:

```python
\boxed{42}
```

Vì vậy majority vote rất dễ.

Nhưng với bài toán mở, ví dụ:

> “Làm sao để cải thiện hệ thống giáo dục đại học trong thời đại AI?”

Các candidate có thể trả lời:

```text
A: Nên cải cách chương trình học, tập trung vào năng lực phản biện.
B: Nên cá nhân hóa giáo dục bằng AI tutor.
C: Nên thay đổi cơ chế đánh giá, bỏ học thuộc.
D: Vấn đề chính là bất bình đẳng truy cập công nghệ.
```

Không có một “đáp án đúng duy nhất”. Các câu trả lời có thể **khác nhau nhưng đồng thời đúng một phần**. Vì vậy “uncertainty” ở đây phải được tách thành nhiều loại:

```text
1. Semantic uncertainty:
   Các câu trả lời có đang nói cùng một hướng không?

2. Factual uncertainty:
   Các câu trả lời có mâu thuẫn về dữ kiện không?

3. Normative uncertainty:
   Các câu trả lời khác nhau vì khác giá trị ưu tiên hay vì model bị rối?

4. Strategic uncertainty:
   Có nhiều phương án khả thi nhưng trade-off khác nhau?

5. Epistemic uncertainty:
   Model thật sự thiếu thông tin / suy luận yếu / chưa xét đủ edge case?
```

Với bài toán mở, **phân kỳ không luôn là xấu**. Đôi khi phân kỳ là dấu hiệu bài toán có nhiều chiều cạnh thật.

---

# 3. Nguyên tắc thiết kế mới: “unstructured output, structured internal state”

Bạn nói final output sẽ là text không cấu trúc. Điều đó ổn. Nhưng bên trong pipeline không nên xử lý text như text thuần.

Ta nên làm như sau:

```text
Raw candidate response
→ internal structured representation
→ uncertainty measurement
→ synthesis
→ final unstructured text
```

Nói cách khác:

```text
Bên ngoài: text tự nhiên.
Bên trong: claim graph / thesis clusters / evidence map / risk flags.
```

Đây là điểm quan trọng nhất.

Với toán:

```python
extract_answer(text) -> int
```

Với bài toán mở:

```python
extract_open_answer(text) -> {
    "main_thesis": str,
    "key_claims": list[str],
    "assumptions": list[str],
    "recommendations": list[str],
    "risks": list[str],
    "evidence": list[str],
    "confidence": float
}
```

Sau đó bạn không vote trên raw text, mà vote / cluster / score trên các trường đã chuẩn hóa.

---

# 4. Kiến trúc đề xuất cho bài toán mở

## 4.1. Data flow mới

```mermaid
graph TD
    A[Open Problem] --> B[Stage 1: Diverse Reasoning Probe]

    B -->|N candidates| C[Candidate Responses]

    C --> D[Semantic Extractor]
    D --> E[Structured Internal Representations]

    E --> F[Semantic Clustering]
    E --> G[Claim-Level Verification]
    E --> H[Assumption & Risk Detection]

    F --> I[Uncertainty Estimator]
    G --> I
    H --> I

    I --> J{Uncertainty Gate}

    J -->|Low uncertainty| K[Synthesize Final Response]

    J -->|High uncertainty| L[Stage 2: Self-Doubt / Adversarial Audit]

    L --> M[Inject conflicting theses, claims, assumptions]
    M --> N[Generate revised candidates]

    N --> O[Re-cluster + Re-score]
    O --> K

    K --> P[Final Free-Form Text Response]
```

---

# 5. Thay `extract_answer()` bằng gì?

Trong code AIMO của bạn:

```python
def extract_answer(text: str) -> Optional[int]:
    ...
```

Với bài toán mở, ta cần một hàm kiểu:

```python
def extract_semantic_signature(text: str) -> dict:
    """
    Convert free-form candidate answer into a normalized semantic representation.
    """
    return {
        "main_position": "...",
        "core_claims": [...],
        "assumptions": [...],
        "recommended_action": "...",
        "risks": [...],
        "unknowns": [...],
        "evidence_used": [...],
    }
```

Ví dụ, với câu hỏi:

> “Có nên dùng AI để chấm bài luận không?”

Candidate 1:

```text
Nên dùng AI như công cụ hỗ trợ, không nên thay thế hoàn toàn giáo viên.
```

Candidate 2:

```text
AI có thể hỗ trợ chấm nháp, nhưng quyết định cuối cùng nên do con người.
```

Raw text khác nhau, nhưng semantic signature gần như giống nhau:

```json
{
  "main_position": "Use AI as assistive grader, not sole authority",
  "recommended_action": "Hybrid human-AI grading",
  "risk": "Bias, opacity, over-reliance"
}
```

Hai candidate này nên được tính là **đồng thuận**, không phải hai đáp án khác nhau.

---

# 6. Thay majority vote bằng semantic clustering

Trong AIMO:

```python
Counter(valid_answers).most_common(1)
```

Với open-ended problem:

```python
clusters = cluster_by_semantic_similarity(candidates)
best_cluster = cluster_with_highest_weight_and_quality(clusters)
```

Có thể dùng 3 cách:

## Cách 1: Embedding clustering

Dùng embedding model để biến mỗi candidate thành vector, rồi cluster.

```text
candidate text → embedding → cosine similarity → cluster
```

Ưu điểm: nhanh, rẻ.

Nhược điểm: dễ gom nhầm nếu hai câu giống văn phong nhưng khác logic.

---

## Cách 2: LLM-as-judge clustering

Dùng một model khác hoặc cùng model ở temperature thấp để hỏi:

```text
Do these two answers advocate the same core position?
Are they compatible, contradictory, or orthogonal?
```

Ưu điểm: hiểu ngữ nghĩa tốt hơn.

Nhược điểm: tốn token, có judge bias.

---

## Cách 3: Hybrid

Tốt nhất là hybrid:

```text
Embedding clustering để gom sơ bộ
→ LLM judge để xác nhận các cụm quan trọng
→ claim-level contradiction check
```

Đây là hướng phù hợp nhất nếu muốn scale nghiêm túc.

---

# 7. Công thức uncertainty mới

Với toán, bạn dùng:

```python
certainty_ratio = max_votes / len(valid_answers)
```

Với bài toán mở, nên dùng một score tổng hợp:

```text
certainty =
    semantic_consensus
    × evidence_consistency
    × judge_agreement
    × assumption_stability
    × low_contradiction_score
```

Một phiên bản đơn giản:

```python
open_certainty = (
    0.35 * semantic_consensus
    + 0.25 * evidence_consistency
    + 0.20 * judge_agreement
    + 0.10 * assumption_stability
    + 0.10 * answer_completeness
)
```

Trong đó:

```text
semantic_consensus:
    Bao nhiêu candidate nằm trong cụm luận điểm chính?

evidence_consistency:
    Các candidate có dùng bằng chứng tương thích không?

judge_agreement:
    Các judge model / audit pass có đồng ý với lựa chọn không?

assumption_stability:
    Kết luận có phụ thuộc vào assumption mong manh không?

answer_completeness:
    Câu trả lời có xử lý đủ khía cạnh chính không?
```

---

# 8. Self-Doubt Prompt cũng phải đổi

Prompt hiện tại của bạn:

```text
We attempted to solve this problem but received conflicting answers: [42, 15, 100, 7].
```

Với bài toán mở, không nên inject chỉ “đáp án”. Nên inject **các luận điểm mâu thuẫn**.

Ví dụ:

```text
We attempted this open-ended problem and received the following competing positions:

Position A:
AI grading should be adopted broadly because it improves scalability and feedback speed.

Position B:
AI grading should only be used as an assistant because it risks bias and opacity.

Position C:
AI grading should not be used in high-stakes assessment until auditability improves.

These positions conflict in their assumptions about reliability, fairness, and accountability.

Your task:
1. Identify which disagreements are factual, normative, or strategic.
2. Determine whether a synthesis is possible.
3. State the strongest final position.
4. Mention the most important caveats.
5. Produce a clear final answer.
```

Đây là bản mở rộng đúng tinh thần “Self-Doubt Activation”.

---

# 9. Bản prompt mới cho open-ended reasoning

## Standard open probe prompt

```python
OPEN_STANDARD_PROMPT = """
You are a rigorous reasoning system.

Analyze the problem carefully.
Produce a high-quality answer, but do not assume there is only one valid perspective.

Your response should:
- identify the core issue,
- state your main position,
- give the strongest reasons,
- mention key assumptions,
- note important caveats,
- end with a clear final recommendation or conclusion.

Problem:
{problem}

Answer:
"""
```

## Semantic extraction prompt

Dùng sau khi sinh candidate:

```python
SEMANTIC_EXTRACTION_PROMPT = """
Extract the semantic structure of the following answer.

Return a JSON object with:
- main_position
- core_claims
- assumptions
- recommended_action
- risks
- caveats
- evidence_used
- unresolved_questions

Answer:
{candidate}
"""
```

## Self-doubt audit prompt

```python
OPEN_SELF_DOUBT_PROMPT = """
We generated several candidate answers to the same open-ended problem.
They disagree in the following ways:

{conflicting_positions}

This may indicate:
- genuine ambiguity,
- missing information,
- hidden assumptions,
- factual uncertainty,
- or flawed reasoning.

Audit the disagreement.

Your task:
1. Separate factual disagreements from value-based disagreements.
2. Identify hidden assumptions behind each position.
3. Decide whether the positions can be synthesized.
4. Reject weak or unsupported claims.
5. Produce the strongest final answer.

Problem:
{problem}

Final audited answer:
"""
```

---

# 10. Pseudocode phiên bản open-ended

```python
def solve_open_problem(model, tokenizer, problem: str) -> str:
    # Stage 1: diverse probe
    prompt_s1 = OPEN_STANDARD_PROMPT.format(problem=problem)
    candidates_s1 = generate_candidates(
        model,
        tokenizer,
        prompt_s1,
        num_samples=5,
        temperature=0.7,
    )

    # Convert free-form text into structured internal representation
    signatures_s1 = [
        extract_semantic_signature(model, tokenizer, c)
        for c in candidates_s1
    ]

    # Cluster by meaning, not exact text
    clusters = semantic_cluster(signatures_s1)

    # Estimate uncertainty
    uncertainty_report = measure_open_uncertainty(
        clusters=clusters,
        signatures=signatures_s1,
    )

    if uncertainty_report.certainty >= 0.75:
        return synthesize_final_answer(
            problem=problem,
            selected_cluster=uncertainty_report.best_cluster,
            caveats=uncertainty_report.caveats,
        )

    # Stage 2: self-doubt activation
    conflict_summary = summarize_conflicts(clusters, signatures_s1)

    prompt_s2 = OPEN_SELF_DOUBT_PROMPT.format(
        problem=problem,
        conflicting_positions=conflict_summary,
    )

    candidates_s2 = generate_candidates(
        model,
        tokenizer,
        prompt_s2,
        num_samples=5,
        temperature=0.6,
    )

    all_candidates = candidates_s1 + candidates_s2

    all_signatures = [
        extract_semantic_signature(model, tokenizer, c)
        for c in all_candidates
    ]

    final_clusters = semantic_cluster(all_signatures)

    final_report = measure_open_uncertainty(
        clusters=final_clusters,
        signatures=all_signatures,
    )

    final_answer = synthesize_final_answer(
        problem=problem,
        selected_cluster=final_report.best_cluster,
        dissenting_clusters=final_report.dissenting_clusters,
        caveats=final_report.caveats,
        uncertainty=final_report.certainty,
    )

    return final_answer
```

---

# 11. Điểm khác biệt lớn: final answer không nên là “winner takes all”

Với toán:

```text
Final answer = đáp án được vote nhiều nhất.
```

Với bài toán mở:

```text
Final answer = synthesis tốt nhất từ các cụm lập luận mạnh nhất.
```

Ví dụ, nếu các candidate chia thành:

```text
Cluster A: "Nên dùng AI grading rộng rãi"             30%
Cluster B: "Nên dùng AI như công cụ hỗ trợ"           50%
Cluster C: "Không nên dùng trong high-stakes exams"   20%
```

Không nên chỉ trả lời theo Cluster B một cách máy móc.

Final tốt hơn là:

```text
The strongest position is a constrained hybrid model:
AI can be used for formative feedback and low-stakes grading, but should not be the sole authority in high-stakes assessment until bias, explainability, appeal mechanisms, and auditability are solved.
```

Đây không chỉ là majority vote. Đây là **consensus synthesis**.

---

# 12. Phân biệt “model uncertainty” và “problem ambiguity”

Đây là điểm rất quan trọng.

Trong toán, nhiều đáp án khác nhau thường nghĩa là model sai / bất định.

Trong bài toán mở, nhiều đáp án khác nhau có thể do:

```text
1. Model thật sự rối.
2. Bài toán thiếu thông tin.
3. Có nhiều hệ giá trị khác nhau.
4. Có nhiều phương án đều hợp lý.
5. Câu hỏi cần làm rõ objective function.
```

Vì vậy uncertainty gate nên phân loại:

```python
class UncertaintyType:
    LOW = "low"
    MODEL_CONFUSION = "model_confusion"
    FACTUAL_UNCERTAINTY = "factual_uncertainty"
    VALUE_CONFLICT = "value_conflict"
    UNDER_SPECIFIED_PROBLEM = "under_specified_problem"
    MULTI_OBJECTIVE_TRADEOFF = "multi_objective_tradeoff"
```

Ví dụ:

```text
Câu hỏi: "Có nên sa thải nhân sự để thay bằng AI không?"

Nếu các candidate khác nhau vì:
- một bên ưu tiên lợi nhuận,
- một bên ưu tiên đạo đức lao động,
- một bên ưu tiên năng lực cạnh tranh dài hạn,

thì đó không đơn thuần là model uncertainty.
Đó là value conflict + multi-objective tradeoff.
```

Final answer lúc này nên nói rõ:

```text
The answer depends on whether the primary objective is short-term cost reduction, long-term capability building, employee trust, legal risk, or social responsibility.
```

---

# 13. Bổ sung module “Objective Clarifier”

Với bài toán mở, nhiều câu hỏi thiếu objective.

Ví dụ:

```text
"Chiến lược tốt nhất cho startup AI là gì?"
```

Không thể trả lời tốt nếu không biết:

```text
- B2B hay B2C?
- runway bao lâu?
- team mạnh ở research hay sales?
- thị trường nào?
- mục tiêu là tăng trưởng, lợi nhuận, hay gọi vốn?
```

Nhưng vì trong hệ thống tự động không thể lúc nào cũng hỏi lại user, pipeline nên tự tạo assumptions:

```text
Assumption Set A: early-stage startup, limited runway
Assumption Set B: research-heavy team, enterprise market
Assumption Set C: consumer AI product, growth objective
```

Sau đó reasoning theo từng assumption set, rồi synthesize.

Đây là generalization rất mạnh của Stage 2.

---

# 14. Với factual open problems, phải thêm retrieval / tools

AIMO là môi trường đóng. Bài toán toán không cần web.

Nhưng open-ended real-world problems thường có dữ kiện thay đổi:

```text
- luật pháp,
- thị trường,
- giá cả,
- chính sách,
- paper mới,
- benchmark mới,
- công nghệ mới,
- thông tin công ty,
- tin tức.
```

Với nhóm bài này, pipeline nên có thêm nhánh:

```text
Uncertainty high due to missing facts
→ Retrieve evidence
→ Verify claims
→ Generate answer grounded in sources
```

Data flow:

```mermaid
graph TD
    A[Open Problem] --> B[Initial Reasoning]
    B --> C[Detect factual claims / missing facts]
    C --> D{Need external evidence?}
    D -->|No| E[Internal Reasoning Pipeline]
    D -->|Yes| F[Retrieval / Search / Database]
    F --> G[Evidence Selection]
    G --> H[Evidence-Grounded Generation]
    H --> I[Contradiction Check]
    I --> J[Final Answer]
```

Không nên dùng self-doubt thuần túy để giải bài cần dữ kiện thật. Nếu thiếu facts, model nghĩ thêm cũng không biến thiếu dữ kiện thành đúng được.

---

# 15. Các domain có thể scale sang

## 15.1. Code / debugging

Thay `boxed integer` bằng:

```text
root cause
minimal patch
test result
risk of regression
```

Verifier có thể là test suite.

```text
Candidate patches → run tests → cluster root causes → select patch
```

Ở domain này, uncertainty không chỉ là vote. Bạn có objective verifier rất mạnh: code có chạy không.

---

## 15.2. Research / scientific reasoning

Thay đáp án bằng:

```text
hypothesis
mechanism
supporting evidence
counterevidence
experiment proposal
```

Self-doubt sẽ inject competing hypotheses.

```text
Hypothesis A: effect is caused by X.
Hypothesis B: effect is caused by Y.
Hypothesis C: observed effect is measurement artifact.
```

Final answer nên là research memo, không phải một kết luận tuyệt đối.

---

## 15.3. Business / strategy

Thay đáp án bằng:

```text
strategic recommendation
decision criteria
assumptions
risks
expected upside
failure modes
```

Uncertainty đến từ assumptions và market facts.

---

## 15.4. Legal / medical / finance

Có thể scale về mặt kỹ thuật, nhưng phải thêm guardrails:

```text
- retrieval bắt buộc,
- citation bắt buộc,
- jurisdiction / context detection,
- uncertainty disclosure,
- không thay thế chuyên gia,
- audit trail.
```

Với các domain high-stakes, self-doubt không đủ. Cần evidence grounding và policy constraints.

---

## 15.5. Creative writing / ideation

Ở đây “uncertainty” không phải đúng/sai mà là chất lượng, novelty, coherence, fit với brief.

Thay majority vote bằng:

```text
diversity sampling
style matching
preference scoring
novelty scoring
constraint checking
```

Final answer có thể tổng hợp các ý hay nhất từ nhiều candidate.

---

# 16. Version kiến trúc tổng quát

Có thể đặt tên module như sau:

```text
Adaptive Open Reasoning Pipeline

1. Probe Generator
   Sinh nhiều hướng giải / quan điểm / phương án.

2. Semantic Normalizer
   Chuyển text tự do thành representation có thể so sánh.

3. Uncertainty Estimator
   Đo semantic dispersion, contradiction, evidence gaps, assumption instability.

4. Reflection Trigger
   Kích hoạt audit khi bất định cao.

5. Adversarial Auditor
   Tấn công các luận điểm yếu, tìm hidden assumptions, tìm failure modes.

6. Evidence Grounder
   Dùng retrieval/tools khi câu hỏi phụ thuộc dữ kiện ngoài.

7. Synthesis Engine
   Không vote thô, mà tổng hợp câu trả lời cuối cùng.

8. Final Response Renderer
   Chuyển structured internal state thành text tự nhiên.
```

---

# 17. Một skeleton code gần với code hiện tại của bạn

```python
from dataclasses import dataclass
from typing import List, Optional, Dict, Any


@dataclass
class OpenSignature:
    main_position: str
    core_claims: List[str]
    assumptions: List[str]
    recommendations: List[str]
    risks: List[str]
    caveats: List[str]
    unresolved_questions: List[str]
    confidence: float


@dataclass
class OpenUncertaintyReport:
    certainty: float
    uncertainty_type: str
    best_cluster_id: int
    conflict_summary: str
    caveats: List[str]
    requires_retrieval: bool


def extract_semantic_signature(
    model,
    tokenizer,
    candidate_text: str,
) -> OpenSignature:
    """
    Use an LLM or parser to convert a free-form answer into a normalized semantic signature.
    In production, force JSON mode if the backend supports it.
    """
    prompt = f"""
Extract the semantic structure of this answer.

Return:
- main_position
- core_claims
- assumptions
- recommendations
- risks
- caveats
- unresolved_questions
- confidence from 0 to 1

Answer:
{candidate_text}
"""
    # generate JSON-like output, parse it, validate fields
    # placeholder:
    return OpenSignature(
        main_position="",
        core_claims=[],
        assumptions=[],
        recommendations=[],
        risks=[],
        caveats=[],
        unresolved_questions=[],
        confidence=0.5,
    )


def semantic_cluster(signatures: List[OpenSignature]) -> Dict[int, List[OpenSignature]]:
    """
    Cluster candidates by main position and compatible core claims.
    Can be implemented using embeddings + LLM judge.
    """
    clusters = {}
    # placeholder implementation
    return clusters


def measure_open_uncertainty(
    signatures: List[OpenSignature],
    clusters: Dict[int, List[OpenSignature]],
) -> OpenUncertaintyReport:
    """
    Estimate uncertainty for open-ended answers.
    """
    total = len(signatures)

    if total == 0:
        return OpenUncertaintyReport(
            certainty=0.0,
            uncertainty_type="no_valid_candidates",
            best_cluster_id=-1,
            conflict_summary="No valid candidate answers were produced.",
            caveats=[],
            requires_retrieval=False,
        )

    # Example placeholder metrics
    largest_cluster_size = max(len(v) for v in clusters.values()) if clusters else 0
    semantic_consensus = largest_cluster_size / total if total else 0.0

    avg_self_confidence = sum(s.confidence for s in signatures) / total

    # In a real system, these would be computed by judge/verifier modules
    evidence_consistency = 0.7
    assumption_stability = 0.7
    contradiction_penalty = 0.2

    certainty = (
        0.40 * semantic_consensus
        + 0.20 * avg_self_confidence
        + 0.20 * evidence_consistency
        + 0.20 * assumption_stability
        - 0.20 * contradiction_penalty
    )

    certainty = max(0.0, min(1.0, certainty))

    best_cluster_id = max(clusters, key=lambda k: len(clusters[k])) if clusters else -1

    return OpenUncertaintyReport(
        certainty=certainty,
        uncertainty_type="semantic_dispersion" if certainty < 0.75 else "low_uncertainty",
        best_cluster_id=best_cluster_id,
        conflict_summary="Candidate answers diverged across major positions.",
        caveats=[],
        requires_retrieval=False,
    )


def synthesize_open_answer(
    model,
    tokenizer,
    problem: str,
    signatures: List[OpenSignature],
    uncertainty_report: OpenUncertaintyReport,
) -> str:
    """
    Produce final free-form answer from structured internal state.
    """
    prompt = f"""
You are producing the final answer to an open-ended problem.

Problem:
{problem}

Internal uncertainty report:
- certainty: {uncertainty_report.certainty}
- uncertainty type: {uncertainty_report.uncertainty_type}
- conflict summary: {uncertainty_report.conflict_summary}

Candidate semantic signatures:
{signatures}

Write a clear, rigorous, useful final answer.
Do not expose implementation details.
Mention caveats only if they materially affect the answer.
"""
    # generate final response
    return "final answer placeholder"


def solve_open_problem(model, tokenizer, problem: str) -> str:
    prompt_s1 = OPEN_STANDARD_PROMPT.format(problem=problem)

    candidates_s1 = generate_candidates(
        model=model,
        tokenizer=tokenizer,
        prompt=prompt_s1,
        num_samples=5,
        temperature=0.7,
    )

    signatures_s1 = [
        extract_semantic_signature(model, tokenizer, c)
        for c in candidates_s1
    ]

    clusters_s1 = semantic_cluster(signatures_s1)

    report_s1 = measure_open_uncertainty(
        signatures=signatures_s1,
        clusters=clusters_s1,
    )

    if report_s1.certainty >= 0.75 and not report_s1.requires_retrieval:
        return synthesize_open_answer(
            model,
            tokenizer,
            problem,
            signatures_s1,
            report_s1,
        )

    conflict_prompt = OPEN_SELF_DOUBT_PROMPT.format(
        problem=problem,
        conflicting_positions=report_s1.conflict_summary,
    )

    candidates_s2 = generate_candidates(
        model=model,
        tokenizer=tokenizer,
        prompt=conflict_prompt,
        num_samples=5,
        temperature=0.6,
    )

    all_candidates = candidates_s1 + candidates_s2

    all_signatures = [
        extract_semantic_signature(model, tokenizer, c)
        for c in all_candidates
    ]

    final_clusters = semantic_cluster(all_signatures)

    final_report = measure_open_uncertainty(
        signatures=all_signatures,
        clusters=final_clusters,
    )

    return synthesize_open_answer(
        model,
        tokenizer,
        problem,
        all_signatures,
        final_report,
    )
```

---

# 18. Một lỗi nhỏ trong report hiện tại của bạn

Trong phần báo cáo bạn viết:

```text
Trong các framework tối ưu tốc độ như vLLM...
```

Nhưng code hiện tại là Transformers + Accelerate, không phải vLLM.

Nên sửa thành:

```text
Trong các framework inference thông thường như Transformers/Accelerate hoặc vLLM, việc sử dụng logit entropy trực tiếp trong pipeline production thường không tiện hoặc tốn chi phí. Do đó, hệ thống dùng output variance như proxy cho epistemic uncertainty.
```

Câu này chính xác hơn và không bị lệch với implementation.

---

# 19. Điểm cần cẩn thận: self-doubt có thể gây anchoring

Inject các đáp án mâu thuẫn vào prompt là ý hay, nhưng có một rủi ro:

```text
Model có thể bị neo vào các đáp án sai đã được liệt kê.
```

Với toán, nếu bạn đưa `[42, 15, 100, 7]`, model có thể nghĩ đáp án đúng chắc nằm trong list.

Với bài toán mở, nếu bạn đưa các position sai hoặc thiếu, model có thể chỉ tranh luận quanh các position đó, thay vì tìm hướng mới.

Prompt Stage 2 nên thêm câu kiểu:

```text
The listed positions may all be flawed. Do not assume the correct answer must be among them.
You may propose a new synthesis or reject all candidate positions.
```

Đây là một cải tiến quan trọng.

---

# 20. Threshold cũng phải động

Trong AIMO bạn dùng:

```python
if certainty >= 0.75:
```

Với bài toán mở, threshold nên phụ thuộc domain:

```text
Toán / code có verifier: threshold cao, ví dụ 0.80–0.90.
Creative ideation: threshold thấp hơn, vì diversity là tốt.
Medical/legal/finance: threshold rất cao, cộng thêm retrieval bắt buộc.
Strategy/business: threshold phụ thuộc mức độ rủi ro.
```

Có thể dùng policy:

```python
DOMAIN_CONFIG = {
    "math": {
        "certainty_threshold": 0.75,
        "requires_retrieval": False,
        "verifier": "answer_vote",
    },
    "code": {
        "certainty_threshold": 0.80,
        "requires_retrieval": False,
        "verifier": "unit_tests",
    },
    "open_strategy": {
        "certainty_threshold": 0.65,
        "requires_retrieval": "depends",
        "verifier": "rubric_judge",
    },
    "medical": {
        "certainty_threshold": 0.90,
        "requires_retrieval": True,
        "verifier": "evidence_grounded_judge",
    },
    "creative": {
        "certainty_threshold": 0.50,
        "requires_retrieval": False,
        "verifier": "preference_score",
    },
}
```

---

# 21. Bản tổng quát hóa từ AIMO sang Open Problems

Có thể mô tả như sau:

```text
AIMO version:
    answer = integer
    agreement = exact match
    uncertainty = answer variance
    final = majority vote

Open-problem version:
    answer = thesis / decision / explanation / plan
    agreement = semantic compatibility
    uncertainty = claim dispersion + evidence gaps + assumption instability
    final = audited synthesis
```

Bảng so sánh:

| Thành phần   | AIMO hiện tại                | Open-ended version                             |
| ------------ | ---------------------------- | ---------------------------------------------- |
| Output       | `\boxed{int}`                | Free-form text                                 |
| Extractor    | Regex số                     | Semantic parser                                |
| Vote         | Exact majority               | Semantic clustering                            |
| Uncertainty  | Output variance              | Claim/assumption/evidence variance             |
| Stage 2      | Conflicting numbers          | Conflicting theses/claims                      |
| Final        | Most common answer           | Synthesized answer                             |
| Verifier     | Modulo / numeric consistency | Rubric, evidence, tests, external tools        |
| Failure mode | Sai số / bẫy logic           | Thiếu ngữ cảnh, mâu thuẫn giá trị, thiếu facts |

---

# 22. Kết luận thiết kế

Có thể scale kiến trúc của bạn ra ngoài toán, nhưng nên hiểu nó không còn là:

```text
majority vote over answers
```

mà trở thành:

```text
adaptive deliberation over hypotheses
```

Công thức tổng quát là:

```text
1. Generate diverse candidate thoughts.
2. Compress each candidate into a semantic signature.
3. Measure disagreement at thesis/claim/assumption/evidence level.
4. If disagreement is low, synthesize directly.
5. If disagreement is high, perform adversarial audit.
6. If facts are missing, retrieve evidence.
7. Produce final free-form answer.
```

Câu quan trọng nhất:

> Với bài toán mở, final output có thể là text không cấu trúc, nhưng tầng đánh giá bên trong bắt buộc phải có cấu trúc.

Nếu không có tầng structured internal representation, hệ thống sẽ rơi lại vào “brute-force prompting”, chỉ là thay majority vote bằng cảm giác chủ quan của model. Còn nếu thêm semantic extraction + clustering + adversarial audit + synthesis, nguyên mẫu AIMO của bạn có thể trở thành một kiến trúc tổng quát cho reasoning trên nhiều domain.
