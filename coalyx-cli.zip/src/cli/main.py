import json
from pathlib import Path

import typer
from rich.prompt import Prompt

from src.core.config import set_config_value, setup_environment, load_config
from src.core.schema import (
    Message, Role, ModelConfig, PipelineMode,
    SessionSnapshot, ContextZone, HookEvent, HookConfig,
)
from src.core.pipeline import run_pipeline
from src.core.monitor import SessionMonitor
from src.memory.context_tracker import create_budget, update_budget, get_zone
from src.memory.compactor import compact_messages, apply_compaction
from src.memory.session_store import (
    generate_session_id, save_session, load_session, list_sessions,
)
from src.memory.project_memory import (
    load_project_memory, scaffold_memory_file, validate_memory_file,
)
from src.extensions.registry import (
    create_registry, register_hook, register_skill, match_skill,
)
from src.extensions.skill_loader import discover_skills
from src.extensions.hook_runner import run_hooks
from src.cli.ui import (
    console, print_welcome, print_error, print_warning, print_info,
    render_dashboard, print_message, print_debug_info,
    print_zone_warning, print_slash_commands,
)

app = typer.Typer(help="Coalyx CLI — Multi-Task AI Chat with Adaptive Reasoning")
config_app = typer.Typer(help="Manage configuration settings")
app.add_typer(config_app, name="config")

COALYX_DIR = ".coalyx"
SESSIONS_DIR = "sessions"
SKILLS_DIR = "skills"
SETTINGS_FILE = "settings.local.json"

MODEL_CONTEXT_LIMITS = {
    "gemini": 1_000_000,
    "gpt-4o": 128_000,
    "gpt-4": 128_000,
    "gpt-3.5": 16_385,
    "claude": 200_000,
    "ollama": 8_192,
}


def _get_context_limit(model_name: str) -> int:
    """Resolve approximate context window size for a model name."""
    lower = model_name.lower()
    for key, limit in MODEL_CONTEXT_LIMITS.items():
        if key in lower:
            return limit
    return 8_192


def _get_project_root() -> Path:
    """Resolve the project root directory."""
    return Path.cwd()


def _get_coalyx_dir() -> Path:
    """Resolve the .coalyx runtime directory."""
    return _get_project_root() / COALYX_DIR


def _load_hooks_from_settings(registry, coalyx_dir: Path) -> None:
    """Load hook configurations from settings.local.json."""
    settings_path = coalyx_dir / SETTINGS_FILE
    if not settings_path.exists():
        return

    try:
        with open(settings_path, "r") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return

    for hook_data in data.get("hooks", []):
        try:
            config = HookConfig(**hook_data)
            register_hook(registry, config)
        except (ValueError, TypeError):
            continue


# --- Config Commands ---

@config_app.command("set")
def config_set(key: str, value: str):
    """Set a configuration value (e.g. gemini-api-key, openai-api-key, ollama-api-base)."""
    set_config_value(key, value)
    console.print(f"[green]✓ Set [bold]{key}[/bold] successfully.[/green]")


@config_app.command("show")
def config_show():
    """Show current configuration (keys are masked)."""
    config = load_config()
    if not config:
        print_info("No configuration set. Use 'coalyx config set <key> <value>'.")
        return

    for key, value in config.items():
        if "key" in key.lower() or "secret" in key.lower():
            masked = value[:4] + "****" + value[-4:] if len(value) > 8 else "****"
            console.print(f"  [cyan]{key}[/cyan]: {masked}")
        else:
            console.print(f"  [cyan]{key}[/cyan]: {value}")


# --- Init Command ---

@app.command("init")
def init_project():
    """Scaffold .coalyx/ directory and COALYX.md in the current project."""
    root = _get_project_root()
    coalyx_dir = root / COALYX_DIR

    (coalyx_dir / SESSIONS_DIR).mkdir(parents=True, exist_ok=True)
    (coalyx_dir / SKILLS_DIR).mkdir(parents=True, exist_ok=True)

    settings_path = coalyx_dir / SETTINGS_FILE
    if not settings_path.exists():
        settings_path.write_text(json.dumps({"hooks": []}, indent=2))

    memory_path = scaffold_memory_file(root)

    console.print(f"[green]✓ Initialized .coalyx/ directory at {coalyx_dir}[/green]")
    console.print(f"[green]✓ Created {memory_path.name}[/green]")
    print_info("Add skills to .coalyx/skills/ and hooks to .coalyx/settings.local.json")


# --- Sessions Command ---

@app.command("sessions")
def list_saved_sessions():
    """List all saved chat sessions."""
    session_dir = _get_coalyx_dir() / SESSIONS_DIR
    sessions = list_sessions(session_dir)

    if not sessions:
        print_info("No saved sessions found.")
        return

    for s in sessions[:10]:
        msg_count = len(s.messages)
        console.print(
            f"  [cyan]{s.session_id}[/cyan] │ {s.model_name} │ "
            f"{msg_count} messages │ {s.updated_at}"
        )


# --- Chat Command ---

@app.command("chat")
def chat(
    model: str = typer.Option(
        "gemini/gemini-2.0-flash",
        help="Model identifier (e.g. gpt-4o, gemini/gemini-2.0-flash, ollama/llama3)",
    ),
    mode: str = typer.Option("instant", help="Mode: 'instant' or 'adaptive'"),
    temperature: float = typer.Option(0.7, help="Generation temperature"),
    resume: str = typer.Option("", help="Resume a saved session by ID"),
):
    """Start an interactive chat session."""
    setup_environment()

    pipeline_mode = PipelineMode.ADAPTIVE if mode.lower() == "adaptive" else PipelineMode.INSTANT
    model_config = ModelConfig(model_name=model, temperature=temperature)
    context_limit = _get_context_limit(model)
    budget = create_budget(context_limit)
    monitor = SessionMonitor(max_context_length=context_limit)
    session_id = generate_session_id()
    messages: list[Message] = []

    # --- Setup extensions ---
    registry = create_registry()
    coalyx_dir = _get_coalyx_dir()
    _load_hooks_from_settings(registry, coalyx_dir)

    skills_dir = coalyx_dir / SKILLS_DIR
    for skill in discover_skills(skills_dir):
        register_skill(registry, skill)

    # --- Load project memory ---
    project_memory = load_project_memory(_get_project_root())
    if project_memory:
        if not validate_memory_file(project_memory):
            print_warning("COALYX.md exceeds 500 lines. Consider trimming it.")
        messages.append(Message(role=Role.SYSTEM, content=project_memory))
        print_info("Loaded project memory from COALYX.md")

    # --- Resume session ---
    if resume:
        session_dir = coalyx_dir / SESSIONS_DIR
        snapshot = load_session(resume, session_dir)
        if snapshot:
            messages = snapshot.messages
            session_id = snapshot.session_id
            print_info(f"Resumed session {session_id} ({len(messages)} messages)")
        else:
            print_error(f"Session '{resume}' not found.")
            return

    # --- Check API key for Adaptive mode ---
    config = load_config()
    if pipeline_mode == PipelineMode.ADAPTIVE and "gemini-api-key" not in config:
        print_error(
            "Adaptive mode requires Gemini Embeddings. "
            "Run 'coalyx config set gemini-api-key <key>' first."
        )
        return

    # --- Fire SESSION_START hooks ---
    run_hooks(registry, HookEvent.SESSION_START, {"session_id": session_id, "model": model})

    print_welcome()
    console.print(
        f"  Mode: [bold]{pipeline_mode.value}[/bold] │ "
        f"Model: [bold]{model}[/bold] │ "
        f"Session: [dim]{session_id}[/dim]\n"
    )
    print_info("Type /help for available commands.\n")

    try:
        while True:
            try:
                user_input = Prompt.ask("[bold cyan]You[/bold cyan]")
            except EOFError:
                break

            if not user_input.strip():
                continue

            # --- Slash commands ---
            if user_input.startswith("/"):
                cmd = user_input.strip().lower()

                if cmd in ("/quit", "/exit", "/q"):
                    break

                elif cmd == "/help":
                    print_slash_commands()
                    continue

                elif cmd == "/status":
                    console.print(render_dashboard(monitor.stats, budget))
                    continue

                elif cmd == "/mode":
                    if pipeline_mode == PipelineMode.INSTANT:
                        pipeline_mode = PipelineMode.ADAPTIVE
                    else:
                        pipeline_mode = PipelineMode.INSTANT
                    print_info(f"Switched to {pipeline_mode.value} mode.")
                    continue

                elif cmd == "/compact":
                    if len(messages) <= 2:
                        print_info("Not enough messages to compact.")
                        continue
                    with console.status("[bold yellow]Compacting...[/bold yellow]", spinner="dots"):
                        result = compact_messages(messages, model)
                    if result.summary:
                        messages = apply_compaction(messages, result)
                        budget = create_budget(context_limit)
                        est_tokens = len(result.summary) // 4
                        budget = update_budget(budget, est_tokens)
                        print_info(
                            f"Compacted {result.original_count} messages → 1 summary. "
                            f"~{result.tokens_saved} tokens freed."
                        )
                    else:
                        print_info("Nothing to compact.")
                    continue

                elif cmd == "/clear":
                    messages = []
                    budget = create_budget(context_limit)
                    project_memory = load_project_memory(_get_project_root())
                    if project_memory:
                        messages.append(Message(role=Role.SYSTEM, content=project_memory))
                    print_info("Session cleared. Project memory reloaded.")
                    continue

                else:
                    print_warning(f"Unknown command: {cmd}. Type /help for available commands.")
                    continue

            # --- Skill matching ---
            matched_skill = match_skill(registry, user_input)
            if matched_skill:
                print_info(f"Skill activated: {matched_skill.name}")
                messages.append(
                    Message(role=Role.SYSTEM, content=matched_skill.instructions)
                )

            # --- Generate response ---
            user_msg = Message(role=Role.USER, content=user_input)
            messages.append(user_msg)

            with console.status("[bold green]Thinking...[/bold green]", spinner="dots"):
                result, debug_info = run_pipeline(messages, model_config, pipeline_mode)

            monitor.update(
                tokens_used=result.tokens_used,
                duration_sec=result.duration_sec,
                model_name=model,
            )
            budget = update_budget(budget, result.tokens_used)

            assistant_msg = Message(role=Role.ASSISTANT, content=result.content)
            messages.append(assistant_msg)

            print_debug_info(debug_info)
            print_message("assistant", result.content)
            console.print(render_dashboard(monitor.stats, budget))
            print_zone_warning(budget.zone)

    except KeyboardInterrupt:
        console.print("\n")

    # --- Fire SESSION_END hooks & save ---
    snapshot = SessionSnapshot(
        session_id=session_id,
        model_name=model,
        mode=pipeline_mode,
        messages=messages,
        total_tokens_used=monitor.stats.total_tokens_used,
    )

    session_dir = _get_coalyx_dir() / SESSIONS_DIR
    try:
        session_dir.mkdir(parents=True, exist_ok=True)
        save_session(snapshot, session_dir)
        print_info(f"Session saved: {session_id}")
    except OSError as e:
        print_warning(f"Could not save session: {e}")

    run_hooks(
        registry, HookEvent.SESSION_END,
        {"session_id": session_id, "total_tokens": monitor.stats.total_tokens_used},
    )

    console.print("[dim]Goodbye.[/dim]")


if __name__ == "__main__":
    app()
