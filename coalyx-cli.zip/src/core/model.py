import time
from typing import List, Optional
import litellm
from litellm import completion

from src.core.schema import Message, GenerationResult

# Suppress litellm logging if desired
litellm.suppress_debug_info = True

def generate_response(
    messages: List[Message],
    model_name: str,
    temperature: float = 0.7,
    max_tokens: int = 2048,
    n: int = 1
) -> List[GenerationResult]:
    """
    Generate response(s) using litellm.
    Args:
        messages: List of conversation messages
        model_name: Model identifier (e.g. 'gemini/gemini-1.5-pro', 'gpt-4o', 'ollama/llama3')
        temperature: Sampling temperature
        max_tokens: Max tokens to generate
        n: Number of candidates to generate
    Returns:
        List of GenerationResult
    """
    formatted_messages = [{"role": msg.role.value, "content": msg.content} for msg in messages]
    
    start_time = time.time()
    try:
        response = completion(
            model=model_name,
            messages=formatted_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            n=n
        )
    except Exception as e:
        raise RuntimeError(f"Generation failed: {str(e)}")
    
    end_time = time.time()
    duration = end_time - start_time
    
    results = []
    # If the provider doesn't support 'n' natively, litellm might return 1 choice anyway.
    # We'll handle multiple choices if returned.
    for choice in response.choices:
        content = choice.message.content or ""
        # Distribute tokens roughly equally if there are multiple choices for tracking
        tokens_used = getattr(response.usage, "total_tokens", 0) // len(response.choices)
        
        results.append(
            GenerationResult(
                content=content,
                tokens_used=tokens_used,
                duration_sec=duration
            )
        )
        
    return results
