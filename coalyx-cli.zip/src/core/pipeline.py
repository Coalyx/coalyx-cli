from typing import List, Tuple
from src.core.schema import Message, ModelConfig, GenerationResult, PipelineMode, Role
from src.core.model import generate_response
from src.core.embedding import calculate_group_consistency

def run_instant_pipeline(messages: List[Message], config: ModelConfig) -> GenerationResult:
    """Run standard generation without reflection."""
    results = generate_response(
        messages=messages,
        model_name=config.model_name,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
        n=1
    )
    return results[0]

def run_adaptive_pipeline(messages: List[Message], config: ModelConfig) -> Tuple[GenerationResult, dict]:
    """
    Run Adaptive Uncertainty-Aware Reasoning pipeline.
    Returns:
        Tuple of (Final Result, Debug Info Dictionary)
    """
    debug_info = {"stage1_candidates": [], "consistency": 0.0, "stage2_triggered": False}
    
    # STAGE 1: Fast Probe (Generate 3 candidates)
    # We make 3 separate calls to ensure compatibility across all providers
    candidates: List[GenerationResult] = []
    total_tokens = 0
    total_duration = 0.0
    
    for _ in range(3):
        res = generate_response(
            messages=messages,
            model_name=config.model_name,
            temperature=0.7, # slightly higher temp for diversity
            max_tokens=config.max_tokens,
            n=1
        )[0]
        candidates.append(res)
        total_tokens += res.tokens_used
        total_duration += res.duration_sec
        
    texts = [c.content for c in candidates]
    debug_info["stage1_candidates"] = texts
    
    # MEASURE UNCERTAINTY
    try:
        consistency = calculate_group_consistency(texts)
    except Exception as e:
        # Fallback if embedding fails (e.g. no API key)
        consistency = 1.0 
        debug_info["embedding_error"] = str(e)
        
    debug_info["consistency"] = consistency
    
    # UNCERTAINTY GATE
    if consistency >= 0.75:
        # High Certainty -> Return the first one as representative
        best = candidates[0]
        best.tokens_used = total_tokens
        best.duration_sec = total_duration
        return best, debug_info
        
    # STAGE 2: Self-Doubt Activation
    debug_info["stage2_triggered"] = True
    
    # Construct self-doubt prompt
    unique_ans = "\n\n---\n\n".join([f"Candidate {i+1}: {t}" for i, t in enumerate(texts)])
    self_doubt_msg = Message(
        role=Role.USER,
        content=(
            "We attempted to solve the previous query but received conflicting answers or perspectives. "
            "Here are the conflicting candidates we generated:\n\n"
            f"{unique_ans}\n\n"
            "Please carefully review these conflicting perspectives, analyze where they diverge or make mistakes, "
            "and provide a final, well-reasoned, and synthesis answer."
        )
    )
    
    reflection_messages = messages + [self_doubt_msg]
    
    final_res = generate_response(
        messages=reflection_messages,
        model_name=config.model_name,
        temperature=0.9, # Higher temp for deeper reasoning
        max_tokens=config.max_tokens,
        n=1
    )[0]
    
    final_res.tokens_used += total_tokens
    final_res.duration_sec += total_duration
    
    return final_res, debug_info

def run_pipeline(messages: List[Message], config: ModelConfig, mode: PipelineMode) -> Tuple[GenerationResult, dict]:
    """Main entry point to route to correct pipeline."""
    if mode == PipelineMode.INSTANT:
        return run_instant_pipeline(messages, config), {}
    else:
        return run_adaptive_pipeline(messages, config)
